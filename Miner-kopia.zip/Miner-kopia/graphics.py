import pygame
class Graphics():

    def __init__(self):
        
        picture=pygame.image.load('./images/diamond.png')
        self.diamond_texture=pygame.transform.scale(picture,(48,48))
        picture2=pygame.image.load('./images/emerald.png')
        self.emerald_texture=pygame.transform.scale(picture2,(48,48))
        picture3=pygame.image.load('./images/gold.png')
        self.gold_texture=pygame.transform.scale(picture3,(48,48))
        self.font = pygame.font.SysFont(None,48)
