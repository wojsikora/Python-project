import pygame

class Clothing():

    def __init__(self):
        pass