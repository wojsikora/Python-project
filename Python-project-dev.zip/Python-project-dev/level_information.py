

class Level_Information():

    def __init__(self):
        self.enemy_quantities=[]
        self.enemy_quantities.append((1,1,1))
        self.enemy_quantities.append((2,0,1))
        self.enemy_quantities.append((1,0,1))
        self.enemy_quantities.append((2,2,0))
        self.enemy_quantities.append((3,0,0))
