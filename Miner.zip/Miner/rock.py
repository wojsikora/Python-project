import pygame
import random
from gameobject import GameObject
class Rock(GameObject):
    #1,0
    GOLD=0
    COPPER=1
    EMERALD=2
    DIAMOND=3
    BEDROCK=4

    def __init__(self,game,destructable,screen):
        super().__init__(game,False)
        self.screen=screen
        self.indestructable_rock=pygame.image.load('images/bedrocktexture.bmp')
        self.destructable=destructable

        if destructable:
            self.mineral=random.randint(0,4)


    # def blitme(self,pos_x,pos_y):
    #     self.rect=pygame.rect.Rect()
    #     self.rect.x=pos_x
    #     self.rect.y=pos_y
    #     self.screen.blit(self.indestructable_rock,self.rect)


    def draw(self,screen,x_center,y_center):
        if self.mineral==self.GOLD:
            rect = pygame.rect.Rect(x_center-24,y_center - 24,48,48)
            pygame.draw.rect(screen, (255, 233,0),rect)
        elif self.mineral==self.COPPER:
            rect = pygame.rect.Rect(x_center-24,y_center - 24,48,48)
            pygame.draw.rect(screen,(220,127,100),rect)
        elif self.mineral==self.EMERALD:
            rect = pygame.rect.Rect(x_center - 24, y_center - 24, 48, 48)
            pygame.draw.rect(screen, (80, 220, 100), rect)
        elif self.mineral == self.DIAMOND:
            rect = pygame.rect.Rect(x_center - 24, y_center - 24, 48, 48)
            pygame.draw.rect(screen, (185,242,255), rect)
        elif self.mineral == self.BEDROCK:
            rect = pygame.rect.Rect(x_center - 24, y_center - 24, 48, 48)
            pygame.draw.rect(screen, (0, 0,0), rect)

    def hit_by_axe(self):
        print("hit by axe")
        self.game.map.remove_game_object(self)
