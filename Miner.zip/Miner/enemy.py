from gameobject import GameObject
import pygame
class Enemy(GameObject):

    def __init__(self,game,health):
        super().__init__(game,False)
        self.health=health
        self.p_attack=10


    def draw(self, screen, x_center, y_center):
        rect = pygame.rect.Rect(x_center - 24, y_center - 24, 48, 48)
        pygame.draw.rect(screen, (0, 0, 0), rect)

    def hit_by_axe(self):
        self.health=0